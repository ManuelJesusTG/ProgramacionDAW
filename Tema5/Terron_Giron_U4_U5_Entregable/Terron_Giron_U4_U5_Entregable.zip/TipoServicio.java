package EntregableTema5;

public enum TipoServicio {

    EDUCATIVO,SANITARIO,DEPORTIVO,OTROS

}
