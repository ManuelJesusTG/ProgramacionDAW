package EntregableTema5;

public interface MostrarPrecioVenta {
    void MostrarPrecioVenta();
}
