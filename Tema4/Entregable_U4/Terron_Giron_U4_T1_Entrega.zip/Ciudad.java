package Entregable_U4;

public enum Ciudad {

    SEVILLA,HUELVA,CADIZ,MALAGA,JAEN,ALMERIA,GRANADA,CORDOBA

}
